$(function () {
    $(".left").addClass("left_border");
    $(".inner_form").load("login1.html");
    $(".right").click(function () {
        $(".inner_form").load("login2.html");
        $(".right").addClass("right_border");
        $(".left").removeClass("left_border");
    });
    $(".left").click(function () {
        $(".inner_form").load("1.html");
        $(".left").addClass("left_border");
        $(".right").removeClass("right_border");
    });
    //注册
    $(".leftr").addClass("left_border");
    $(".inner_formr").load("resgter1.html");
    $(".rightr").click(function () {
        $(".inner_formr").load("resgter2.html");
        $(".rightr").addClass("right_border");
        $(".leftr").removeClass("left_border");
    });
    $(".leftr").click(function () {
        $(".inner_formr").load("resgter1.html");
        $(".leftr").addClass("left_border");
        $(".rightr").removeClass("right_border");
    });
    //忘记密码
    $(".leftf").addClass("left_border");
    $(".inner_formf").load("forget1.html");
    $(".rightf").click(function () {
        $(".inner_formf").load("forget2.html");
        $(".rightf").addClass("right_border");
        $(".leftf").removeClass("left_border");
    });
    $(".leftf").click(function () {
        $(".inner_formf").load("forget1.html");
        $(".leftf").addClass("left_border");
        $(".rightf").removeClass("right_border");
    });

});
function createCode() {
    code = "";
    var codeLength = 4;
    var selcetChar = new Array(0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 'q', 'w', 'e', 'r', 't', 'y', 'u', 'i', 'o', 'p', 'a', 's', 'd', 'f', 'g', 'h',
        'j', 'k', 'l', 'z', 'x', 'c', 'v', 'b', 'n', 'm');
    for (var i = 0; i < codeLength; i++) {
        var charIndex = Math.floor(Math.random() * 36);
        code += selcetChar[charIndex];
    }
    var discode = document.getElementById("discode");
    discode.style.fontFamily = "Fixedsys";
    discode.style.color = "#0ab000";
    discode.style.letterSpacing = "3px";
    discode.style.padding = "1px";
    discode.innerHTML = code;
}